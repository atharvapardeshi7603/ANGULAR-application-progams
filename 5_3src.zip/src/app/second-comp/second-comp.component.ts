import { Component } from '@angular/core';

@Component({
  selector: 'app-second-comp',
  standalone: true,
  imports: [],
  templateUrl: './second-comp.component.html',
  styleUrl: './second-comp.component.css'
})
export class SecondCompComponent 
{

}
