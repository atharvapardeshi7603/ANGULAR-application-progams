import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent 
{
  title = 'FunctionDemo3';

  public Name : string = "";

  public upper()
  {
    this.Name = "MARVELLOUS INFOSYSTEMS";
  }
  public lower()
  {
    this.Name = "marvellous infosystems";
  }

}
